function _1(md){return(
md`# Data Visualization - seconda parte - artificial network`
)}

function _2(md){return(
md`Nella seconda parte del progetto di data visualization, abbiamo implementato una mappa interattiva dell'Italia. Le funzionalità della mappa includono:

1. **Selezione delle Regioni**: L'utente può cliccare su una regione per selezionarla. Per resettare la selezione o selezionare una nuova regione, è sufficiente cliccare al di fuori dei confini italiani oppure su un'altra regione.
2. **Interazione tramite Hover**: La mappa permette l'interazione tramite hover, offrendo dettagli contestuali al passaggio del cursore su una regione.
3. **Funzione di Zoom**: La mappa supporta lo zoom tramite la rotella del mouse, consentendo un'esplorazione dettagliata delle diverse aree geografiche.
`
)}

function _3(d3,limits_it_regions,topojson)
{
  const width = 1000;
  const height = 1000;
  
  const zoom = d3.zoom()
    .scaleExtent([1, 8])
    .on("zoom", zoomed);
  
  const projection = d3.geoMercator().fitSize([width, height], limits_it_regions)
  
  const features = limits_it_regions.features;

  const svg = d3.create("svg")
      .attr("viewBox", [0, 0, width, height])
      .attr("width", width)
      .attr("height", height)
      .attr("style", "max-width: 100%; height: auto;")
      .on("click", reset);
  
  const path = d3.geoPath().projection(projection);
  const g = svg.append("g");
  
 const states = g.append("g")
      .attr("fill", "#444")
      .attr("cursor", "pointer")
      .selectAll("path")
      .data(features)
      .join("path")
      .on("click", clicked)
      .attr("d", path);
  
  states.append("title")
      .text(d => d.properties.reg_name);
  
  g.append("path")
      .attr("fill", "none")
      .attr("stroke", "white")
      .attr("stroke-linejoin", "round")
      .attr("d", path(topojson.mesh(limits_it_regions, limits_it_regions.features, (a, b) => a !== b)));
  
  function reset() {
    states.transition().style("fill", null);
    svg.transition().duration(750).call(
      zoom.transform,
      d3.zoomIdentity,
      d3.zoomTransform(svg.node()).invert([width / 2, height / 2])
    );
  }

  svg.call(zoom);
  
  function clicked(event, d) {
    const [[x0, y0], [x1, y1]] = path.bounds(d);
    event.stopPropagation();
    states.transition().style("fill", null);
    d3.select(this).transition().style("fill", "red");
    svg.transition().duration(750).call(
      zoom.transform,
      d3.zoomIdentity
        .translate(width / 2, height / 2)
        .scale(Math.min(8, 0.9 / Math.max((x1 - x0) / width, (y1 - y0) / height)))
        .translate(-(x0 + x1) / 2, -(y0 + y1) / 2),
      d3.pointer(event, svg.node())
    );
  }

  function zoomed(event) {
    const {transform} = event;
    g.attr("transform", transform);
    g.attr("stroke-width", 1 / transform.k);
  }
  
  return svg.node()
}


function _limits_it_regions(FileAttachment){return(
FileAttachment("limits_IT_regions@1.geojson").json()
)}

function _5(md){return(
md`Successivamente, abbiamo proceduto con la visualizzazione della rete sociale, suddividendola in base al livello di istruzione degli individui, rappresentati dai nodi. Abbiamo utilizzato un modello di forze attrattive, in cui per ogni tipologia di istruzione viene creato un centro attrattivo, attirando i nodi corrispondenti. Anche in questa visualizzazione è disponibile la funzionalità di hovering, permettendo di ottenere informazioni al passaggio del cursore su ciascun nodo.`
)}

function _artificial_network_graph(FileAttachment){return(
FileAttachment("artificial_network_graph@1.json").json()
)}

function _drag(d3){return(
simulation => {
  
  function dragstarted(event, d) {
    if (!event.active) simulation.alphaTarget(0.3).restart();
    d.fx = d.x;
    d.fy = d.y;
  }
  
  function dragged(event, d) {
    d.fx = event.x;
    d.fy = event.y;
  }
  
  function dragended(event, d) {
    if (!event.active) simulation.alphaTarget(0);
    d.fx = null;
    d.fy = null;
  }
  
  return d3.drag()
      .on("start", dragstarted)
      .on("drag", dragged)
      .on("end", dragended);
}
)}

function _8(artificial_network_graph,d3,drag,invalidation)
{

  const height = 1200;
  const width = 1200;  

  // Ottieni tutte le istruzioni presenti nei nodi
  const instructions = Array.from(new Set(artificial_network_graph.nodes.map(d => d.instruction)));

  // Genera i centri delle istruzioni
  const instructionCenters = {};
  instructions.forEach((instruction, i) => {
    instructionCenters[instruction] = {
      x: (i % 2 === 0 ? width / 4 : (3 * width) / 4), 
      y: (i < 2 ? height / 4 : (3 * height) / 4)
    };
  });

  const color = d3.scaleOrdinal(d3.schemeCategory10);
  
 const simulation = d3.forceSimulation(artificial_network_graph.nodes)
      .force("link", d3.forceLink(artificial_network_graph.links).id(d => d.id))
      .force("charge", d3.forceManyBody().strength(-30)) 
      .force("center", d3.forceCenter(width / 2, height / 2))
      .force("x", d3.forceX(d => instructionCenters[d.instruction].x).strength(0.5)) 
      .force("y", d3.forceY(d => instructionCenters[d.instruction].y).strength(0.5)); 
  
  const svg = d3.create("svg")
      .attr("viewBox", [0, 0, width, height]);

  const link = svg.append("g")
      .attr("stroke", "#999")
      .attr("stroke-opacity", 0.6)
      .selectAll("line")
      .data(artificial_network_graph.links)
      .join("line")
      .attr("stroke-width", 1);  

  const node = svg.append("g")
      .attr("stroke", "#fff")
      .attr("stroke-width", 1.5)
      .selectAll("circle")
      .data(artificial_network_graph.nodes)
      .join("circle")
      .attr("r", 5)
      .attr("fill", d => color(d.instruction))
      .call(drag(simulation));

  node.append("title")
      .text(d => ("Istruzione: " + d.instruction + ", età:" + d.age));   

  simulation.on("tick", () => {
    link
        .attr("x1", d => d.source.x)
        .attr("y1", d => d.source.y)
        .attr("x2", d => d.target.x)
        .attr("y2", d => d.target.y);

    node
        .attr("cx", d => d.x)
        .attr("cy", d => d.y);
  });

  invalidation.then(() => simulation.stop());

  return svg.node();
}


function _9(md){return(
md`Abbiamo poi integrato la rete nella mappa interattiva dell'Italia precedentemente mostrata, al fine di visualizzare la distribuzione spaziale dei nodi. In questa integrazione, sono state mantenute tutte le funzionalità elencate in precedenza riguardo la mappa e l'hovering dei nodi.`
)}

function _real_network_graph(FileAttachment){return(
FileAttachment("real_network_graph@1.json").json()
)}

function _11(real_network_graph,d3,limits_it_regions,topojson)
{
 const width = 1000;
  const height = 1000;
  const nodes = real_network_graph.nodes.map(node => ({ ...node }));
  const zoom = d3.zoom()
    .scaleExtent([1, 8])
    .on("zoom", zoomed);
  
  const color_node = d3.scaleOrdinal(d3.schemeCategory10);
  
  const projection = d3.geoMercator().fitSize([width, height], limits_it_regions);
  
  const features = limits_it_regions.features;
  
  const svg = d3.create("svg")
    .attr("viewBox", [0, 0, width, height])
    .attr("width", width)
    .attr("height", height)
    .attr("style", "max-width: 100%; height: auto;")
    .on("click", reset);
  
  const path = d3.geoPath().projection(projection);
  const g = svg.append("g");
  
  const networkLayer = svg.append("g");
  
  // Funzione per aggiungere jitter alle coordinate
  function addJitter(coordinate, scale = 6) {
    const jitter = (Math.random() - 0.5) * scale;
    return coordinate + jitter;
  }
  
  // Aggiungi i nodi al grafico
  const node = networkLayer.append("g")
    .attr("stroke", "#fff")
    .attr("stroke-width", 0.3)
    .selectAll("circle")
    .data(nodes)
    .join("circle")
    .attr("r", 1.2)
    .attr("fill", d => color_node(d.instruction))
    .attr("cx", d => addJitter(projection([d.longitude, d.latitude])[0]))
    .attr("cy", d => addJitter(projection([d.longitude, d.latitude])[1]));
  
  node.append("title")
    .text(d => ("Istruzione: " + d.instruction + ", età:" + d.age));
  
  const states = g.append("g")
    .attr("fill", "#444")
    .attr("cursor", "pointer")
    .selectAll("path")
    .data(features)
    .join("path")
    .on("click", clicked)
    .attr("d", path);
  
  states.append("title")
    .text(d => d.properties.reg_name);
  
  g.append("path")
    .attr("fill", "none")
    .attr("stroke", "white")
    .attr("stroke-linejoin", "round")
    .attr("d", path(topojson.mesh(limits_it_regions, limits_it_regions.features, (a, b) => a !== b)));
  
  function reset() {
    states.transition().style("fill", null);
    svg.transition().duration(750).call(
      zoom.transform,
      d3.zoomIdentity,
      d3.zoomTransform(svg.node()).invert([width / 2, height / 2])
    );
  
    // Mostra tutti i nodi
    node.style("display", "block");
  }
  
  svg.call(zoom);
  
  function zoomed(event) {
    const { transform } = event;
    g.attr("transform", transform);
    g.attr("stroke-width", 1 / transform.k);
    networkLayer.attr("transform", transform);
  }
  
  function clicked(event, d) {
    const [[x0, y0], [x1, y1]] = path.bounds(d);
    event.stopPropagation();
    states.transition().style("fill", null);
    d3.select(this).transition().style("fill", "red");
    svg.transition().duration(750).call(
      zoom.transform,
      d3.zoomIdentity
        .translate(width / 2, height / 2)
        .scale(Math.min(8, 0.9 / Math.max((x1 - x0) / width, (y1 - y0) / height)))
        .translate(-(x0 + x1) / 2, -(y0 + y1) / 2),
      d3.pointer(event, svg.node())
    );
  
    // Filtra i nodi per mostrare solo quelli all'interno della regione
    node.style("display", n => isNodeInRegion(n, d) ? "block" : "none");
  }
  
  // Funzione per controllare se un nodo è all'interno di una regione
  function isNodeInRegion(node, region) {
    const [longitude, latitude] = [node.longitude, node.latitude];
    return d3.geoContains(region, [longitude, latitude]);
  }
  
  return svg.node();

}


function _12(md){return(
md`Sono stati aggiunti dei pulsanti con cui l'utente può scegliere quale set di dati visualizzare, oltre a una legenda per migliorare la comprensione dei dati. In questa rappresentazione, i centri attrattivi sono stati ridefiniti: anziché basarsi sul tipo di istruzione, i nodi vengono ora attratti verso centri specifici in base allo stato in cui si trovano, ossia 'Infected', 'Susceptible' o 'Recovered'.`
)}

function _inital_status_infection_and_debunking_test_1_hubs(FileAttachment){return(
FileAttachment("inital_status_infection_and_debunking_test_1_hubs@2.json").json()
)}

function _final_status_infection_and_debunking_test_1_hubs(FileAttachment){return(
FileAttachment("final_status_infection_and_debunking_test_1_hubs.json").json()
)}

function _final_status_infection_and_debunking_test_2_hubs(FileAttachment){return(
FileAttachment("final_status_infection_and_debunking_test_2_hubs@1.json").json()
)}

function _final_status_infection_and_debunking_test_3_hubs(FileAttachment){return(
FileAttachment("final_status_infection_and_debunking_test_3_hubs.json").json()
)}

function _final_status_infection_and_debunking_test_4_hubs(FileAttachment){return(
FileAttachment("final_status_infection_and_debunking_test_4_hubs@1.json").json()
)}

function _final_status_infection_and_debunking_test_5_hubs(FileAttachment){return(
FileAttachment("final_status_infection_and_debunking_test_5_hubs@1.json").json()
)}

function _19(inital_status_infection_and_debunking_test_1_hubs,width,d3,drag,final_status_infection_and_debunking_test_1_hubs,final_status_infection_and_debunking_test_2_hubs,final_status_infection_and_debunking_test_3_hubs,final_status_infection_and_debunking_test_4_hubs,final_status_infection_and_debunking_test_5_hubs,color_legend,invalidation)
{
  const height = 1400;
 // const width = 1200;
  
  // Get all unique colors present in the nodes
  const colors = Array.from(new Set(inital_status_infection_and_debunking_test_1_hubs.nodes.map(d => d.color)));
  
  // Generate the centers for each color
  const colorCenters = {};
  colors.forEach((color, i) => {
    colorCenters[color] = {
      x: (i % 2 === 0 ? width / 4 : (3 * width) / 4),
      y: (i < 2 ? height / 4 : (3 * height) / 4)
    };
  });
  
  // Initialize nodes and links with the initial data
  let nodes = inital_status_infection_and_debunking_test_1_hubs.nodes.map(d => ({...d}));
  let links = inital_status_infection_and_debunking_test_1_hubs.links.map(d => ({...d}));
  
  const simulation = d3.forceSimulation(nodes)
    .force("link", d3.forceLink(links).id(d => d.id))
    .force("charge", d3.forceManyBody().strength(-30))
    .force("center", d3.forceCenter(width / 2, height / 2))
    .force("x", d3.forceX(d => colorCenters[d.color].x).strength(0.5))
    .force("y", d3.forceY(d => colorCenters[d.color].y).strength(0.5));
  
  const svg = d3.create("svg")
    .attr("viewBox", [0, 0, width, height]);
  
  let link = svg.append("g")
    .attr("stroke", "#999")
    .attr("stroke-opacity", 0.6)
    .selectAll("line")
    .data(links)
    .join("line")
    .attr("stroke-width", 1);
  
  let node = svg.append("g")
    .attr("stroke", "#fff")
    .attr("stroke-width", 1.5)
    .selectAll("circle")
    .data(nodes)
    .join("circle")
    .attr("r", 5)
    .attr("fill", d => d.color)
    .call(drag(simulation));
  
  node.append("title")
    .text(d => ("Istruzione: " + d.instruction + ", età:" + d.age));
  
  // Add selection panel
  const selectionPanel = svg.append("g")
    .attr("transform", "translate(10, 10)");
  
  const selectionButtons = selectionPanel.append("g")
    .attr("transform", "translate(0, 25)");
  
  const dataOptions = ["Initial Status", "After Test 1", "After Test 2", "After Test 3", "After Test 4", "After Test 5"];
  
  const buttonWidth = 120;
  const buttonHeight = 30;
  const buttonSpacing = 10;
  
  let selectedButton = null;
  const buttons = selectionButtons.selectAll("g")
    .data(dataOptions)
    .enter()
    .append("g")
    .attr("transform", (d, i) => `translate(${i * (buttonWidth + buttonSpacing)}, 0)`)
    .style("cursor", "pointer")
    .on("click", (event, d) => {
      const newData = loadData(d); // Load data based on selection
      updateNetworkData(newData); // Update visualization with new data
  
      // Update button styles
      if (selectedButton) {
        selectedButton.select("rect").style("fill", "gray");
      }
      d3.select(event.currentTarget).select("rect").style("fill", "black");
      selectedButton = d3.select(event.currentTarget);
    });
  
  buttons.append("rect")
    .attr("width", buttonWidth)
    .attr("height", buttonHeight)
    .attr("rx", 5)
    .attr("ry", 5)
    .style("fill", "gray")
    .style("stroke", "#aaa")
    .style("stroke-width", 1);
  
  buttons.append("text")
    .attr("x", buttonWidth / 2)
    .attr("y", buttonHeight / 2 + 4)
    .attr("text-anchor", "middle")
    .text(d => d)
    .style("pointer-events", "none")
    .style("fill", "white");
  
  
  // Function to load data (replace with your data loading logic)
  const loadData = (dataSelection) => {
    let nodes;
    let links;
  
    if (dataSelection === "Initial Status") {
      nodes = inital_status_infection_and_debunking_test_1_hubs.nodes.map((node) => ({ ...node }));
      links = inital_status_infection_and_debunking_test_1_hubs.links.map((link) => ({ ...link }));
    } else if (dataSelection === "After Test 1") {
      nodes = final_status_infection_and_debunking_test_1_hubs.nodes.map((node) => ({ ...node }));
      links = final_status_infection_and_debunking_test_1_hubs.links.map((link) => ({ ...link }));
    } else if (dataSelection === "After Test 2") {
      nodes = final_status_infection_and_debunking_test_2_hubs.nodes.map((node) => ({ ...node }));
      links = final_status_infection_and_debunking_test_2_hubs.links.map((link) => ({ ...link }));
    } else if (dataSelection === "After Test 3") {
      nodes = final_status_infection_and_debunking_test_3_hubs.nodes.map((node) => ({ ...node }));
      links = final_status_infection_and_debunking_test_3_hubs.links.map((link) => ({ ...link }));
    } else if (dataSelection === "After Test 4") {
      nodes = final_status_infection_and_debunking_test_4_hubs.nodes.map((node) => ({ ...node }));
      links = final_status_infection_and_debunking_test_4_hubs.links.map((link) => ({ ...link }));
    }else{
      nodes = final_status_infection_and_debunking_test_5_hubs.nodes.map((node) => ({ ...node }));
      links = final_status_infection_and_debunking_test_5_hubs.links.map((link) => ({ ...link }));
    }  
    return { nodes, links };
  };
  
  // Function to update network based on data selection
  const updateNetworkData = (newData) => {
    // Update nodes and links with the new data
    nodes = newData.nodes;
    links = newData.links;
  
    // Update nodes
    node = node.data(nodes, d => d.id)
      .join(
        enter => enter.append("circle")
          .attr("stroke", "#fff")
          .attr("stroke-width", 1.5)
          .attr("r", 5)
          .attr("fill", d => d.color)
          .call(enter => enter.transition().duration(1000).attr("r", 5)),
        update => update.call(update => update.transition().duration(1000).attr("fill", d => d.color)),
        exit => exit.call(exit => exit.transition().duration(1000).attr("r", 0).remove())
      );
  
    node.append("title")
      .text(d => ( "Age: " + d.age + ", Instructions: "+  d.instruction));
  
    // Update links
    link = link.data(links, d => `${d.source.id}-${d.target.id}`)
      .join(
        enter => enter.append("line")
          .attr("stroke", "#999")
          .attr("stroke-opacity", 0.6)
          .attr("stroke-width", 1),
        update => update,
        exit => exit.remove()
      );
  
    // Update simulation with new nodes and links
    simulation.nodes(nodes);
    simulation.force("link").links(links);
  
    // Restart the simulation
    simulation.alpha(1).restart();
  };

  const legend = svg.append("g")
    .attr("transform", "translate(100, 100)")
  
  const size = 20;
  const border_padding = 15;
  const item_padding = 5;
  const text_offset = 2;
  const x = 1100;
  const y = 1000;
  
  const palette = ["red", "green", "blue"];
  const domains = ["Infected", "Recovered", "Susceptible"];
  // Border
  legend
    .append('rect')
    .attr("width", 135)
    .attr("height", 110)
    .attr("x", x)
    .attr("y", y)
    .style("fill", "none")
    .style("stroke-width", 1)
    .style("stroke", "black");
  
  // Boxes
  legend.selectAll("boxes")
    .data(domains)
    .enter()
    .append("rect")
      .attr("x", (border_padding) + x)
      .attr("y", (d, i) => y + border_padding + (i * (size + item_padding)))
      .attr("width", size)
      .attr("height", size)
      .style("fill", (d) => color_legend(d));
  
  // Labels
  legend.selectAll("labels")
    .data(domains)
    .enter()
    .append("text")
      .attr("x", border_padding + size + item_padding + x)
      .attr("y", (d, i) => y + border_padding + i * (size + item_padding) + (size / 2) + text_offset)
      .text((d) => d)
      .attr("text-anchor", "left")
      .style("alignment-baseline", "middle")
      .style("font-family", "sans-serif");
  
  simulation.on("tick", () => {
    link
      .attr("x1", d => d.source.x)
      .attr("y1", d => d.source.y)
      .attr("x2", d => d.target.x)
      .attr("y2", d => d.target.y);
  
    node
      .attr("cx", d => d.x)
      .attr("cy", d => d.y);
  });
  
  invalidation.then(() => simulation.stop());
  
  return svg.node();
}


function _20(md){return(
md`Infine, mantenendo le proprietà finora descritte, viene visualizzata la rete con i nodi colorati in base al loro stato, presentando due versioni: una senza i collegamenti tra i nodi e una con i collegamenti. Inoltre, i collegamenti assumono il colore dello stato del nodo di partenza.`
)}

function _21(inital_status_infection_and_debunking_test_1_hubs,d3,limits_it_regions,topojson,color_legend,final_status_infection_and_debunking_test_1_hubs,final_status_infection_and_debunking_test_2_hubs,final_status_infection_and_debunking_test_3_hubs,final_status_infection_and_debunking_test_4_hubs,final_status_infection_and_debunking_test_5_hubs)
{
  const width = 1000;
  const height = 1000;
  let nodes = inital_status_infection_and_debunking_test_1_hubs.nodes.map(node => ({ ...node }));
  const zoom = d3.zoom()
    .scaleExtent([1, 8])
    .on("zoom", zoomed);
  
  const projection = d3.geoMercator().fitSize([width, height], limits_it_regions)
  
  const features = limits_it_regions.features;
  
  const svg = d3.create("svg")
    .attr("viewBox", [0, 0, width, height])
    .attr("width", width)
    .attr("height", height)
    .attr("style", "max-width: 100%; height: auto;")
    .on("click", reset);
  
  const path = d3.geoPath().projection(projection);
  const g = svg.append("g");
  
  const networkLayer = svg.append("g");

 // Funzione per aggiungere jitter alle coordinate
  function addJitter(coordinate, scale = 6) {
    const jitter = (Math.random() - 0.5) * scale;
    return coordinate + jitter;
  }
 
  // Add nodes to the graph
  let node = networkLayer.append("g")
    .attr("stroke", "#fff")
    .attr("stroke-width", 0.3)
    .selectAll("circle")
    .data(nodes)
    .join("circle")
    .attr("r", 1.2)
    .attr("fill", d => d.color)
    .attr("cx", d => addJitter(projection([d.longitude, d.latitude])[0]))
    .attr("cy", d => addJitter(projection([d.longitude, d.latitude])[1]));
  
  node.append("title")
    .text(d => ("Istruzione: " + d.instruction + ", età:" + d.age));
  
  const states = g.append("g")
    .attr("fill", "#444")
    .attr("cursor", "pointer")
    .selectAll("path")
    .data(features)
    .join("path")
    .on("click", clicked)
    .attr("d", path);
  
  states.append("title")
    .text(d => d.properties.reg_name);
  
  g.append("path")
    .attr("fill", "none")
    .attr("stroke", "white")
    .attr("stroke-linejoin", "round")
    .attr("d", path(topojson.mesh(limits_it_regions, limits_it_regions.features, (a, b) => a !== b)));
  
  const selectionPanel = svg.append("g")
    .attr("transform", "translate(10, 10)"); // Adjust positioning as needed
  
  const selectionButtons = selectionPanel.append("g")
    .attr("transform", "translate(0, 25)"); // Adjust spacing
  
  const dataOptions = ["Initial Status", "After Test 1", "After Test 2", "After Test 3", "After Test 4", "After Test 5"];
  
  const buttonWidth = 120;
  const buttonHeight = 30;
  const buttonSpacing = 10;
  let selectedButton = null;
  const buttons = selectionButtons.selectAll("g")
    .data(dataOptions)
    .enter()
    .append("g")
    .attr("transform", (d, i) => `translate(${i * (buttonWidth + buttonSpacing)}, 0)`)
    .style("cursor", "pointer")
    .on("click", (event, d) => {
      const newData = loadData(d); // Load data based on selection
      nodes = newData.nodes; // Update nodes variable
      updateNetworkData(); // Call the update function to reflect changes
      // Update button styles
      if (selectedButton) {
        selectedButton.select("rect").style("fill", "gray");
      }
      d3.select(event.currentTarget).select("rect").style("fill", "black");
      selectedButton = d3.select(event.currentTarget);
    });
  
  buttons.append("rect")
    .attr("width", buttonWidth)
    .attr("height", buttonHeight)
    .attr("rx", 5) // Rounded corners
    .attr("ry", 5)
    .attr("fill", "#ddd")
    .attr("stroke", "#aaa")
    .attr("stroke-width", 1)
    .style("fill", "gray")
    .style("stroke", "#aaa")
    .style("stroke-width", 1);
  
  buttons.append("text")
    .attr("x", buttonWidth / 2)
    .attr("y", buttonHeight / 2 + 4) // Center text vertically
    .attr("text-anchor", "middle")
    .text(d => d)
    .style("pointer-events", "none")
    .style("fill", "white");

  const legend = svg.append("g")
    .attr("transform", "translate(100, 100)")
  
  const size = 20;
  const border_padding = 15;
  const item_padding = 5;
  const text_offset = 2;
  const x = 5;
  const y = 750;
  
  const palette = ["red", "green", "blue"];
  const domains = ["Infected", "Recovered", "Susceptible"];
  // Border
  legend
    .append('rect')
    .attr("width", 135)
    .attr("height", 110)
    .attr("x", x)
    .attr("y", y)
    .style("fill", "none")
    .style("stroke-width", 1)
    .style("stroke", "black");
  
  // Boxes
  legend.selectAll("boxes")
    .data(domains)
    .enter()
    .append("rect")
      .attr("x", (border_padding) + x)
      .attr("y", (d, i) => y + border_padding + (i * (size + item_padding)))
      .attr("width", size)
      .attr("height", size)
      .style("fill", (d) => color_legend(d));
  
  // Labels
  legend.selectAll("labels")
    .data(domains)
    .enter()
    .append("text")
      .attr("x", border_padding + size + item_padding + x)
      .attr("y", (d, i) => y + border_padding + i * (size + item_padding) + (size / 2) + text_offset)
      .text((d) => d)
      .attr("text-anchor", "left")
      .style("alignment-baseline", "middle")
      .style("font-family", "sans-serif");
  
  // Function to load data (replace with your data loading logic)
  const loadData = (dataSelection) => {
    let nodes;
  
    if (dataSelection === "Initial Status") {
      nodes = inital_status_infection_and_debunking_test_1_hubs.nodes.map((node) => ({ ...node }));
    } else if (dataSelection === "After Test 1") {
      nodes = final_status_infection_and_debunking_test_1_hubs.nodes.map((node) => ({ ...node }));
    } else if (dataSelection === "After Test 2") {
      nodes = final_status_infection_and_debunking_test_2_hubs.nodes.map((node) => ({ ...node }));
    } else if (dataSelection === "After Test 3") {
      nodes = final_status_infection_and_debunking_test_3_hubs.nodes.map((node) => ({ ...node }));
    } else if (dataSelection === "After Test 4") {
      nodes = final_status_infection_and_debunking_test_4_hubs.nodes.map((node) => ({ ...node }));
    }else{
      nodes = final_status_infection_and_debunking_test_5_hubs.nodes.map((node) => ({ ...node }));
    }
  
    return { nodes };
  };
  
  // Function to update network based on data selection
  const updateNetworkData = () => {
    node.remove()
  
    // Update nodes (using D3 data join)
    node = networkLayer.selectAll("circle")
      .data(nodes)
      .join(
        enter => enter.append("circle")
          .attr("stroke", "#fff")
          .attr("stroke-width", 0.3)
          .attr("r", 1.2)
          .attr("fill", d => d.color)
          .attr("cx", d => addJitter(projection([d.longitude, d.latitude])[0]))
          .attr("cy", d => addJitter(projection([d.longitude, d.latitude])[1])),
        update => update
          .attr("fill", d => d.instruction)
          .attr("cx", d => addJitter(projection([d.longitude, d.latitude])[0]))
          .attr("cy", d => addJitter(projection([d.longitude, d.latitude])[1])),
        exit => exit.call(exit => exit.transition().duration(1000).attr("r", 0).remove())
      );
  };
  
  function reset() {
    states.transition().style("fill", null);
    svg.transition().duration(750).call(
      zoom.transform,
      d3.zoomIdentity,
      d3.zoomTransform(svg.node()).invert([width / 2, height / 2]));
  
    // Show all nodes
    node.style("display", "block");
  }
  
  svg.call(zoom);
  
  function zoomed(event) {
    const { transform } = event;
    g.attr("transform", transform);
    g.attr("stroke-width", 1 / transform.k);
    networkLayer.attr("transform", transform);
  }
  
  function clicked(event, d) {
    const [[x0, y0], [x1, y1]] = path.bounds(d);
    event.stopPropagation();
    states.transition().style("fill", null);
    d3.select(this).transition().style("fill", "red");
    svg.transition().duration(750).call(
      zoom.transform,
      d3.zoomIdentity
        .translate(width / 2, height / 2)
        .scale(Math.min(8, 0.9 / Math.max((x1 - x0) / width, (y1 - y0) / height)))
        .translate(-(x0 + x1) / 2, -(y0 + y1) / 2),
      d3.pointer(event, svg.node()));
  
    // Filter nodes to show only those within the region
    node.style("display", n => isNodeInRegion(n, d) ? "block" : "none");
  }
  
  // Function to check if a node is within a region
  function isNodeInRegion(node, region) {
    const [longitude, latitude] = [node.longitude, node.latitude];
    return d3.geoContains(region, [longitude, latitude]);
  }
  
  return svg.node();
}


function _22(inital_status_infection_and_debunking_test_1_hubs,d3,limits_it_regions,topojson,color_legend,final_status_infection_and_debunking_test_1_hubs,final_status_infection_and_debunking_test_2_hubs,final_status_infection_and_debunking_test_3_hubs,final_status_infection_and_debunking_test_4_hubs,final_status_infection_and_debunking_test_5_hubs)
{
  const width = 1000;
  const height = 1000;
  let nodes = inital_status_infection_and_debunking_test_1_hubs.nodes.map(node => ({ ...node }));
  let links = inital_status_infection_and_debunking_test_1_hubs.links.map(link => ({ ...link }));
  
  const zoom = d3.zoom()
    .scaleExtent([1, 8])
    .on("zoom", zoomed);
  
  const projection = d3.geoMercator().fitSize([width, height], limits_it_regions);
  
  const features = limits_it_regions.features;
  
  const svg = d3.create("svg")
    .attr("viewBox", [0, 0, width, height])
    .attr("width", width)
    .attr("height", height)
    .attr("style", "max-width: 100%; height: auto;")
    .on("click", reset);
  
  const path = d3.geoPath().projection(projection);
  const g = svg.append("g");
  
  const networkLayer = svg.append("g");

  // Funzione per aggiungere jitter alle coordinate
  function addJitter(coordinate, scale = 6) {
    const jitter = (Math.random() - 0.5) * scale;
    return coordinate + jitter;
  }
  
  // Aggiungi i nodi al grafico
  let node = networkLayer.append("g")
    .attr("stroke", "#fff")
    .attr("stroke-width", 0.3)
    .selectAll("circle")
    .data(nodes)
    .join("circle")
    .attr("r", 1.2)
    .attr("fill", d => d.color)
    .attr("cx", d => addJitter(projection([d.longitude, d.latitude])[0]))
    .attr("cy", d => addJitter(projection([d.longitude, d.latitude])[1]));
  
  // Aggiungi i collegamenti al grafico
  let link = networkLayer.append("g")
    .attr("stroke-opacity", 0.03)
    .selectAll("line")
    .data(links)
    .join("line")
    .attr("stroke-width", 0.3)
    .attr("stroke", d => nodes[d.source].color) // Colore del nodo sorgente
    .attr("x1", d => projection([nodes[d.source].longitude, nodes[d.source].latitude])[0])
    .attr("y1", d => projection([nodes[d.source].longitude, nodes[d.source].latitude])[1])
    .attr("x2", d => projection([nodes[d.target].longitude, nodes[d.target].latitude])[0])
    .attr("y2", d => projection([nodes[d.target].longitude, nodes[d.target].latitude])[1]);
  
  node.append("title")
    .text(d => ( "Age: " + d.age + ", Instructions: "+  d.instruction));
  
  const states = g.append("g")
    .attr("fill", "#444")
    .attr("cursor", "pointer")
    .selectAll("path")
    .data(features)
    .join("path")
    .on("click", clicked)
    .attr("d", path);
  
  states.append("title").text(d => d.properties.reg_name);
  
  g.append("path")
    .attr("fill", "none")
    .attr("stroke", "white")
    .attr("stroke-linejoin", "round")
    .attr("d", path(topojson.mesh(limits_it_regions, limits_it_regions.features, (a, b) => a !== b)));
  
  function reset() {
    states.transition().style("fill", null);
    svg.transition().duration(750).call(
      zoom.transform,
      d3.zoomIdentity,
      d3.zoomTransform(svg.node()).invert([width / 2, height / 2])
    );
  
    // Mostra tutti i nodi e i link
    node.style("display", "block");
    link.style("display", "block")
    .attr("stroke", d => nodes[d.source].color)
    .attr("stroke-opacity", 0.03);
  }
  
  const selectionPanel = svg.append("g")
    .attr("transform", "translate(10, 10)"); // Adjust positioning as needed
  
  
  const selectionButtons = selectionPanel.append("g")
    .attr("transform", "translate(0, 25)"); // Adjust spacing
  
 
  const dataOptions = ["Initial Status", "After Test 1", "After Test 2", "After Test 3", "After Test 4", "After Test 5"];
  
  const buttonWidth = 120;
  const buttonHeight = 30;
  const buttonSpacing = 10;
  let selectedButton = null;
  const buttons = selectionButtons.selectAll("g")
    .data(dataOptions)
    .enter()
    .append("g")
    .attr("transform", (d, i) => `translate(${i * (buttonWidth + buttonSpacing)}, 0)`)
    .style("cursor", "pointer")
    .on("click", (event, d) => {
      const newData = loadData(d); // Load data based on selection
      nodes = newData.nodes; // Update nodes variable
      updateNetworkData(); // Call the update function to reflect changes
      // Update button styles
      if (selectedButton) {
        selectedButton.select("rect").style("fill", "gray");
      }
      d3.select(event.currentTarget).select("rect").style("fill", "black");
      selectedButton = d3.select(event.currentTarget);
    });
  
  buttons.append("rect")
    .attr("width", buttonWidth)
    .attr("height", buttonHeight)
    .attr("rx", 5) // Rounded corners
    .attr("ry", 5)
    .attr("fill", "#ddd")
    .attr("stroke", "#aaa")
    .attr("stroke-width", 1)
    .style("fill", "gray")
    .style("stroke", "#aaa")
    .style("stroke-width", 1);
  
  buttons.append("text")
    .attr("x", buttonWidth / 2)
    .attr("y", buttonHeight / 2 + 4) // Center text vertically
    .attr("text-anchor", "middle")
    .text(d => d)
    .style("pointer-events", "none")
    .style("fill", "white");

   const legend = svg.append("g")
    .attr("transform", "translate(100, 100)")
  
  const size = 20;
  const border_padding = 15;
  const item_padding = 5;
  const text_offset = 2;
  const x = 5;
  const y = 750;
  
  const palette = ["red", "green", "blue"];
  const domains = ["Infected", "Recovered", "Susceptible"];
  // Border
  legend
    .append('rect')
    .attr("width", 135)
    .attr("height", 110)
    .attr("x", x)
    .attr("y", y)
    .style("fill", "none")
    .style("stroke-width", 1)
    .style("stroke", "black");
  
  // Boxes
  legend.selectAll("boxes")
    .data(domains)
    .enter()
    .append("rect")
      .attr("x", (border_padding) + x)
      .attr("y", (d, i) => y + border_padding + (i * (size + item_padding)))
      .attr("width", size)
      .attr("height", size)
      .style("fill", (d) => color_legend(d));
  
  // Labels
  legend.selectAll("labels")
    .data(domains)
    .enter()
    .append("text")
      .attr("x", border_padding + size + item_padding + x)
      .attr("y", (d, i) => y + border_padding + i * (size + item_padding) + (size / 2) + text_offset)
      .text((d) => d)
      .attr("text-anchor", "left")
      .style("alignment-baseline", "middle")
      .style("font-family", "sans-serif");
  
  // Function to load data (replace with your data loading logic)
  const loadData = (dataSelection) => {
    let nodes;
    let links;
  
    if (dataSelection === "Initial Status") {
      nodes = inital_status_infection_and_debunking_test_1_hubs.nodes.map((node) => ({ ...node }));
      links = inital_status_infection_and_debunking_test_1_hubs.links.map((link) => ({ ...link }));
    } else if (dataSelection === "After Test 1") {
      nodes = final_status_infection_and_debunking_test_1_hubs.nodes.map((node) => ({ ...node }));
      links = final_status_infection_and_debunking_test_1_hubs.links.map((link) => ({ ...link }));
    } else if (dataSelection === "After Test 2") {
      nodes = final_status_infection_and_debunking_test_2_hubs.nodes.map((node) => ({ ...node }));
      links = final_status_infection_and_debunking_test_2_hubs.links.map((link) => ({ ...link }));
    } else if (dataSelection === "After Test 3") {
      nodes = final_status_infection_and_debunking_test_3_hubs.nodes.map((node) => ({ ...node }));
      links = final_status_infection_and_debunking_test_3_hubs.links.map((link) => ({ ...link }));
    } else if (dataSelection === "After Test 4") {
      nodes = final_status_infection_and_debunking_test_4_hubs.nodes.map((node) => ({ ...node }));
      links = final_status_infection_and_debunking_test_4_hubs.links.map((link) => ({ ...link }));
    }else{
      nodes = final_status_infection_and_debunking_test_5_hubs.nodes.map((node) => ({ ...node }));
      links = final_status_infection_and_debunking_test_5_hubs.links.map((link) => ({ ...link }));
    }
  
    return { nodes, links };
  };
  
 //Function to update network based on data selection
  const updateNetworkData = () => {
    node.remove()
    link.remove()
    // Update nodes (using D3 data join)
    node = networkLayer.selectAll("circle")
      .data(nodes)
      .join(
        enter => enter.append("circle")
          .attr("stroke", "#fff")
          .attr("stroke-width", 0.3)
          .attr("r", 1.2)
          .attr("fill", d => d.color)
          .attr("cx", d => addJitter(projection([d.longitude, d.latitude])[0]))
          .attr("cy", d => projection([d.longitude, d.latitude])[1]),
        update => update
          .attr("fill", d => d.color)
          .attr("cx", d => addJitter(projection([d.longitude, d.latitude])[0]))
          .attr("cy", d => addJitter(projection([d.longitude, d.latitude])[1])),
        exit => exit.call(exit => exit.transition().duration(1000).attr("r", 0).remove())
      );
  
    
    // Update links (using D3 data join)
    link = networkLayer.selectAll("line")
      .data(links)
      .join(
        enter => enter.append("line")
          .attr("stroke-width", 0.3)
          .attr("x1", d => projection([nodes[d.source].longitude, nodes[d.source].latitude])[0])
          .attr("y1", d => projection([nodes[d.source].longitude, nodes[d.source].latitude])[1])
          .attr("x2", d => projection([nodes[d.target].longitude, nodes[d.target].latitude])[0])
          .attr("y2", d => projection([nodes[d.target].longitude, nodes[d.target].latitude])[1])
          .attr("stroke", d => nodes[d.source].color), 
        update => update
          .attr("x1", d => projection([nodes[d.source].longitude, nodes[d.source].latitude])[0])
          .attr("y1", d => projection([nodes[d.source].longitude, nodes[d.source].latitude])[1])
          .attr("x2", d => projection([nodes[d.target].longitude, nodes[d.target].latitude])[0])
          .attr("y2", d => projection([nodes[d.target].longitude, nodes[d.target].latitude])[1])
          .attr("stroke", d => nodes[d.source].color),
        exit => exit.remove()
      );
  };
  svg.call(zoom);
  
  function zoomed(event) {
    const { transform } = event;
    g.attr("transform", transform);
    g.attr("stroke-width", 1 / transform.k);
    networkLayer.attr("transform", transform);
  }
  
  function clicked(event, d) {
    const [[x0, y0], [x1, y1]] = path.bounds(d);
    event.stopPropagation();
    states.transition().style("fill", null);
    d3.select(this).transition().style("fill", "red");
    svg.transition().duration(750).call(
      zoom.transform,
      d3.zoomIdentity
        .translate(width / 2, height / 2)
        .scale(Math.min(8, 0.9 / Math.max((x1 - x0) / width, (y1 - y0) / height)))
        .translate(-(x0 + x1) / 2, -(y0 + y1) / 2),
      d3.pointer(event, svg.node())
    );
  
    // Filtra i nodi per mostrare solo quelli all'interno della regione
    node.style("display", n => isNodeInRegion(n, d) ? "block" : "none");
  
    // Filtra i link per mostrare solo quelli tra i nodi della regione selezionata
    link.style("display", l => {
      const sourceNode = nodes[l.source];
      const targetNode = nodes[l.target];
      return isNodeInRegion(sourceNode, d) && isNodeInRegion(targetNode, d) ? "block" : "none";
    })
     .attr("stroke", "black")
     .attr("stroke-opacity", 0.6);
  }
  
  // Funzione per controllare se un nodo e' all'interno di una regione
  function isNodeInRegion(node, region) {
    const [longitude, latitude] = [node.longitude, node.latitude];
    return d3.geoContains(region, [longitude, latitude]);
  }
  
  return svg.node();
}


function _domains(){return(
["Infected", "Recovered", "Susceptible"]
)}

function _palette(){return(
["red", "green", "blue"]
)}

function _color_legend(d3,palette,domains){return(
d3.scaleOrdinal(palette).domain(domains)
)}

export default function define(runtime, observer) {
  const main = runtime.module();
  function toString() { return this.url; }
  const fileAttachments = new Map([
    ["artificial_network_graph@1.json", {url: new URL("./files/7521318101bc45a36938b3be067b37e5a31b72e17dc423460e3942068d6176a6b55350f0b01188b181baf7471bb302e8842ddffaaac3f88fe890b309c89de269.json", import.meta.url), mimeType: "application/json", toString}],
    ["real_network_graph@1.json", {url: new URL("./files/a9a8b869c1569afa11a637527b50da2c991929ff4c7bcebfdf44d248c61808f8fba3931467e549e6217c529f38f39fe6f3db7ec016ccbebd179652d848932a96.json", import.meta.url), mimeType: "application/json", toString}],
    ["inital_status_infection_and_debunking_test_1_hubs@2.json", {url: new URL("./files/37589ad1470c1434273631bd8af9558413ce4c67b40552c334130c7c02a1ac35b1a31654fc7940a8a5ee40dcd7e2d7303d42dbb06582f6ffa7f77bfff092b659.json", import.meta.url), mimeType: "application/json", toString}],
    ["final_status_infection_and_debunking_test_5_hubs@1.json", {url: new URL("./files/8caf610f717e5cc65bf7103cd68a14e26fd596ceb29b0e084b382c246dedbac8ad6867aacb36d0e107069c4d6155febf7f62e9e261a5bd6f658ee6b1b9a55017.json", import.meta.url), mimeType: "application/json", toString}],
    ["final_status_infection_and_debunking_test_4_hubs@1.json", {url: new URL("./files/9016059262149b6d2958338f5740972174616db480e7da367f279b52fa4df41a971c193b24dac60f13650decf3a920ae4d7d13e78adc64d11ff34b0cbc25a535.json", import.meta.url), mimeType: "application/json", toString}],
    ["final_status_infection_and_debunking_test_3_hubs.json", {url: new URL("./files/7c96a8bb94a538f833096be83eea136781d34cbe0be9a1c153c3636636ba8007e91829974fd41e68f48830f354f76663938fe585fa8604fdbffb8aa6827da93c.json", import.meta.url), mimeType: "application/json", toString}],
    ["final_status_infection_and_debunking_test_2_hubs@1.json", {url: new URL("./files/03ed8ed6bda9f797a68440cd0bc13d8ab34156f5d8ff8d0e56d283476227d1ebaaabf9a1b46e8bf4dd3199ac92475de201c3ebf76f6edfb0b5064368c441c01e.json", import.meta.url), mimeType: "application/json", toString}],
    ["final_status_infection_and_debunking_test_1_hubs.json", {url: new URL("./files/a56fa0d7ab9770bc5af6a3ad7bcbe2de300941b6db4e18656e4c2571da0fb671f00d5f282fc6d55a589625bd55cea23642695015a8ff37cee6e81a747dd57113.json", import.meta.url), mimeType: "application/json", toString}],
    ["limits_IT_regions@1.geojson", {url: new URL("./files/78f7cdeb59e25802165a63de761bfbe3157cc696d7dab18242c130759ca1dd646a9998142d9075386fca3498fbcaea557e5fffe9c14b1ada7aa2f84968353e1b.geojson", import.meta.url), mimeType: "application/geo+json", toString}]
  ]);
  main.builtin("FileAttachment", runtime.fileAttachments(name => fileAttachments.get(name)));
  main.variable(observer()).define(["md"], _1);
  main.variable(observer()).define(["md"], _2);
  main.variable(observer()).define(["d3","limits_it_regions","topojson"], _3);
  main.variable(observer("limits_it_regions")).define("limits_it_regions", ["FileAttachment"], _limits_it_regions);
  main.variable(observer()).define(["md"], _5);
  main.variable(observer("artificial_network_graph")).define("artificial_network_graph", ["FileAttachment"], _artificial_network_graph);
  main.variable(observer("drag")).define("drag", ["d3"], _drag);
  main.variable(observer()).define(["artificial_network_graph","d3","drag","invalidation"], _8);
  main.variable(observer()).define(["md"], _9);
  main.variable(observer("real_network_graph")).define("real_network_graph", ["FileAttachment"], _real_network_graph);
  main.variable(observer()).define(["real_network_graph","d3","limits_it_regions","topojson"], _11);
  main.variable(observer()).define(["md"], _12);
  main.variable(observer("inital_status_infection_and_debunking_test_1_hubs")).define("inital_status_infection_and_debunking_test_1_hubs", ["FileAttachment"], _inital_status_infection_and_debunking_test_1_hubs);
  main.variable(observer("final_status_infection_and_debunking_test_1_hubs")).define("final_status_infection_and_debunking_test_1_hubs", ["FileAttachment"], _final_status_infection_and_debunking_test_1_hubs);
  main.variable(observer("final_status_infection_and_debunking_test_2_hubs")).define("final_status_infection_and_debunking_test_2_hubs", ["FileAttachment"], _final_status_infection_and_debunking_test_2_hubs);
  main.variable(observer("final_status_infection_and_debunking_test_3_hubs")).define("final_status_infection_and_debunking_test_3_hubs", ["FileAttachment"], _final_status_infection_and_debunking_test_3_hubs);
  main.variable(observer("final_status_infection_and_debunking_test_4_hubs")).define("final_status_infection_and_debunking_test_4_hubs", ["FileAttachment"], _final_status_infection_and_debunking_test_4_hubs);
  main.variable(observer("final_status_infection_and_debunking_test_5_hubs")).define("final_status_infection_and_debunking_test_5_hubs", ["FileAttachment"], _final_status_infection_and_debunking_test_5_hubs);
  main.variable(observer()).define(["inital_status_infection_and_debunking_test_1_hubs","width","d3","drag","final_status_infection_and_debunking_test_1_hubs","final_status_infection_and_debunking_test_2_hubs","final_status_infection_and_debunking_test_3_hubs","final_status_infection_and_debunking_test_4_hubs","final_status_infection_and_debunking_test_5_hubs","color_legend","invalidation"], _19);
  main.variable(observer()).define(["md"], _20);
  main.variable(observer()).define(["inital_status_infection_and_debunking_test_1_hubs","d3","limits_it_regions","topojson","color_legend","final_status_infection_and_debunking_test_1_hubs","final_status_infection_and_debunking_test_2_hubs","final_status_infection_and_debunking_test_3_hubs","final_status_infection_and_debunking_test_4_hubs","final_status_infection_and_debunking_test_5_hubs"], _21);
  main.variable(observer()).define(["inital_status_infection_and_debunking_test_1_hubs","d3","limits_it_regions","topojson","color_legend","final_status_infection_and_debunking_test_1_hubs","final_status_infection_and_debunking_test_2_hubs","final_status_infection_and_debunking_test_3_hubs","final_status_infection_and_debunking_test_4_hubs","final_status_infection_and_debunking_test_5_hubs"], _22);
  main.variable(observer("domains")).define("domains", _domains);
  main.variable(observer("palette")).define("palette", _palette);
  main.variable(observer("color_legend")).define("color_legend", ["d3","palette","domains"], _color_legend);
  return main;
}
